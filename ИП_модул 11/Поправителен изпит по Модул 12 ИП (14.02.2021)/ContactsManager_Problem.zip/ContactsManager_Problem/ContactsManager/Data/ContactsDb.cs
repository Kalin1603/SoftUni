﻿using Data.Entity;
using Microsoft.EntityFrameworkCore;

namespace Data
{
    public class ContactsDb : DbContext
    {
        public virtual DbSet<Contact> Contacts { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=localhost;Database=ContactsDb;User Id=sa;Password=!Nikipass1;");
            optionsBuilder.UseLazyLoadingProxies();
        }
    }
}
