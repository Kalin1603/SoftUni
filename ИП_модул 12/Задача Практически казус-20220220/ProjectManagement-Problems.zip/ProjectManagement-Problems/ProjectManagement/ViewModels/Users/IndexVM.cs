﻿using ProjectManagement.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectManagement.ViewModels.Users
{
    public class IndexVM
    {
        public List<User> Items { get; set; }
    }
}
