﻿using ProjectManagement.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectManagement.ViewModels.Projects
{
    public class IndexVM
    {
        public List<Project> Items { get; set; }
    }
}
